﻿using System;
namespace rootver021
{
	class rootver021
	{
		static void Main(string[] args)
		{
			Console.WriteLine("+++++++++++++++++++++++++++++++++++++");
			Console.WriteLine("+                                   +");
			Console.WriteLine("+   *****         *       **     *  +");
			Console.WriteLine("+   *    *       * *      * *    *  +");
			Console.WriteLine("+   *     *     *   *     *  *   *  +");
			Console.WriteLine("+   *     *    * *** *    *   *  *  +");
			Console.WriteLine("+   *    *    *       *   *    * *  +");
			Console.WriteLine("+   *****    *         *  *     **  +");
			Console.WriteLine("+                                   +");
			Console.WriteLine("+++++++++++++++++++++++++++++++++++++");
			Console.WriteLine("欢迎游玩【Root】版本号Ver0.2.1");
			int finalchoice = 0;
			while (true)
			{
				Console.WriteLine("请选择你的武器！（输入对应的数字！）");
				Thread.Sleep(2000);
				Console.WriteLine("1.大太刀 伤害2000 暴击率20%");
				Console.WriteLine("2.巨型加农炮 伤害1000 暴击率50%");
				Console.WriteLine("3.鸡骨头 伤害为30 但是具有双重暴击率！暴击率99%");
				if (!int.TryParse(Console.ReadLine(), out int choice))
				{
					Console.WriteLine("警告：请输入数字，不要输入字母！");
					continue;
				}
				bool xz = true;
				switch (choice)
				{
					case 1:
						Console.WriteLine("你选择了【大太刀】！");

						break;
					case 2:
						Console.WriteLine("你选择了【巨型加农炮】！");

						break;
					case 3:
						Console.WriteLine("你选择了【鸡骨头】！");

						break;
					default:
						Console.WriteLine("输入有误，请重新输入！");
						xz = false;
						break;
				}
				if (xz)
				{
					finalchoice = choice;
					break;
				}
			}
			int diren = 0;
			Thread.Sleep(2000);
			Console.WriteLine($"你的敌人是{Direnshuchu(diren)}");
			Thread.Sleep(2000);
			int shanghai = 0;
			if (finalchoice == 1)
			{
				shanghai = 2000;
			}
			else if (finalchoice == 2)
			{
				shanghai = 1000;
			}
			else if (finalchoice == 3)
			{
				shanghai = 30;
			}
			Console.WriteLine($"你造成了{shanghai}！");
			if (Baoji(finalchoice) == 2)
			{
				Console.WriteLine("【暴击】!!");
				int shanghai2 = shanghai * 2;
				Console.WriteLine($"暴击伤害！{shanghai2}！");
			}
			else
			{
				Console.WriteLine("没有暴击！");
			}
			Console.WriteLine("游戏结束 按任意键退出游戏");
			Console.ReadKey();
			static string Direnshuchu(int dirensuijijisuan)
			{
				Random rand = new Random();
				int diren = rand.Next(0, 4);
				diren = dirensuijijisuan + diren;
				if (diren == 1)
				{
					return "小怪-史莱姆";
				}
				else if (diren == 2)
				{
					return "小怪-哥布林";
				}
				else if (diren == 3)
				{
					return "小怪-骷髅兵";
				}
				else
				{
					return "强大的未知敌人";
				}

			}
			static int Baoji(int weaponchoice)
			{
				Random rand = new Random();
				if (weaponchoice == 1)
				{
					int baoji = rand.Next(1, 101);
					if (baoji <= 20)
					{
						return 2;
					}
					else
					{
						return 1;
					}
				}
				if (weaponchoice == 2)
				{
					int baoji = rand.Next(1, 101);
					if (baoji <= 50)
					{
						return 2;
					}
					else
					{
						return 1;
					}
				}
				if (weaponchoice == 3)
				{
					int baoji1 = rand.Next(1, 101);
					int baoji2 = rand.Next(1, 101);
					if (baoji1 <= 99 || baoji2 <= 99)
					{
						return 2;
					}
					else
					{
						return 1;
					}
				}
				else
				{
					return 1;
				}




			}


		}

	}
}