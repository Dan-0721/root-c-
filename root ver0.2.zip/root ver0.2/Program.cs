﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
namespace RootVer02
{
	class rootver02
	{
		static void Main()
		{
			int i = 1;
			for (; i > 0;)
			{
				Console.WriteLine("请选择你的武器 1.大剑 2.太刀 3.盾斧");
			    int choice=int.Parse(Console.ReadLine());
			
				if (choice == 1)
				{
					Console.WriteLine("你选择了大剑!");
					i = 0;
				}
				else if (choice == 2)
				{
					Console.WriteLine("你选择了太刀!");
					i= 0;
				}
				else if (choice == 3)
				{
					Console.WriteLine("你选择了盾斧!");
					i= 0;
				}
				else
				{
					Console.WriteLine("选择无效,请重新选择！");
					
				}
			}
            Console.WriteLine("输入你武器的伤害！");
			int damage = int.Parse(Console.ReadLine());
            Console.WriteLine("你的对手是【黑龙】！");
            Console.WriteLine($"你造成了{Attack(damage)}!");
			Console.WriteLine($"本次狩猎总输出为：{Attack1(damage)}!额外输出{damage*3*2-damage}！");



		}
		static string Attack(int damage)
		{

			damage = damage * 3;
			if (damage >= 100) 
			{
                return"【会心一击！】"; 
			}
			else
			{
				return"【普通攻击】";
			}
		}
		static int Attack1(int damage1)
		{
			return damage1 = damage1 * 3*2;
			

		}
	}
}
